# Changelog

All notable changes to this template will be documented in this file

## [1.1.0] - [2023-10-31]

### Updated

- Updated Bootstrap to latest version(5.3.2)
- Updated SCSS & Mixins as per Bootstrap 5.3.2

### Fixed

- Carousel HTML Structure as per latest Bootstrap
- Minor improvements & Bugfixes

## [1.0.1] - [2023-09-26]

### Added

- Linting, formatting, .git, vscode extensions & setting files

## [1.0.0] - [2023-09-20]

### Added

- Initial Release
